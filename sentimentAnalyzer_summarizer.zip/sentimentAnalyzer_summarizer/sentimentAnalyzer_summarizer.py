import tkinter as tk
from tkinter import filedialog, scrolledtext, messagebox
import PyPDF2
from textblob import TextBlob
import fitz
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize, sent_tokenize
from nltk.probability import FreqDist
import heapq
def read_pdf(file_path):
    try:
        doc = fitz.open(file_path)
        text = ""
        for page in doc:
            text += page.get_text()
        return text
    except Exception as e:
        print(f"Error reading PDF: {e}")
        return None

def textsumzer(plaintext, num_sentences=5):
    sentences = sent_tokenize(plaintext)
    words = word_tokenize(plaintext.lower())
    stop_words = set(stopwords.words("english"))
    words = [word for word in words if word not in stop_words]
    word_freq = FreqDist(words)
    sent_scores = {}
    for sentence in sentences:
        for word in word_tokenize(sentence.lower()):
            if word in word_freq:
                if sentence not in sent_scores:
                    sent_scores[sentence] = word_freq[word]
                else:
                    sent_scores[sentence] += word_freq[word]
    summary_sentences = heapq.nlargest(num_sentences, sent_scores, key=sent_scores.get)
    summary = ' '.join(summary_sentences)
    return summary
def analyze_sentiment(text):
    analysis = TextBlob(text)
    sentiment = analysis.sentiment.polarity
    if sentiment > 0:
        return "Positive Sentiment/content"
    elif sentiment == 0:
        return "Neutral Sentiment/content"
    else:
        return "Negative Sentiment/conten"
def sum_n_anlz():
    input_text = text_box.get("1.0", tk.END)
    if not input_text.strip():
        messagebox.showwarning("Warning", "Please enter some text.")
        return
    summary = textsumzer(input_text)
    sentiment = analyze_sentiment(input_text)

    summary_text.delete("1.0", tk.END)
    summary_text.insert(tk.END, f"Summary:\n{summary}\n\nSentiment: {sentiment}")
def open_file():
    file_path = filedialog.askopenfilename(filetypes=[("PDF files", "*.pdf")])
    if not file_path:
        return
    extracted_text = read_pdf(file_path)
    text_box.delete("1.0", tk.END)
    text_box.insert(tk.END, extracted_text)
    sum_n_anlz()
def reset():
    text_box.delete("1.0", tk.END)
    summary_text.delete("1.0", tk.END)
root = tk.Tk()
root.title("Sentiment Analizer and Text Summarizer")
frame = tk.Frame(root)
frame.pack(pady=10)
label = tk.Label(frame, text="Enter text or open a pdf file:")
label.pack()
text_box = scrolledtext.ScrolledText(frame, width=80, height=10, wrap=tk.WORD)
text_box.pack(pady=10)
button_frame = tk.Frame(root)
button_frame.pack(pady=5)
open_button = tk.Button(button_frame, text="Open pdf", command=open_file)
open_button.grid(row=0, column=0, padx=5)
analyze_button = tk.Button(button_frame, text="Summarize & Analyze", command=sum_n_anlz)
analyze_button.grid(row=0, column=1, padx=5)
reset_button = tk.Button(button_frame, text="Reset", command=reset)
reset_button.grid(row=0, column=2, padx=5)
summary_text = scrolledtext.ScrolledText(root, width=80, height=10, wrap=tk.WORD)
summary_text.pack(pady=10)
root.mainloop()
